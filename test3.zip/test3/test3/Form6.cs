﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using MySql.Data.MySqlClient;

namespace test3
{
    public partial class Form6 : Form
    {
        DelTest _del;

        //define a global variable for datagridview1.rows
        int dataset2;
        //connect to the mysql database
        string str = "server = 127.0.0.1;user id = root;password=wuxi*2001;database=stone_processing_system";

        public Form6(DelTest del)
        {
            this._del = del;
            InitializeComponent();
        }

        private void Form6_Load(object sender, EventArgs e)
        {
            MySqlConnection mysqlconncetion = new MySqlConnection(str);
            mysqlconncetion.Open();
            try
            {
                string tool_information = "select toolbaseinfo.toolnumber,toolname,length,diameter,toolnoseradius,toolmaterial,numberofflutes,maxspeedallowed,maxfeedallowed from toolbaseinfo,usageinfo,toolpysicalinfo where toolbaseinfo.toolnumber = usageinfo.toolnumber AND usageinfo.toolnumber = toolpysicalinfo.toolnumber";
                MySqlDataAdapter toolinfo_adapter = new MySqlDataAdapter(tool_information, mysqlconncetion);
                DataSet stonesysteminfo = new DataSet();
                toolinfo_adapter.Fill(stonesysteminfo, "tool_information");
                dataset2 = stonesysteminfo.Tables["tool_information"].Rows.Count;
                for (int i = 0; i < stonesysteminfo.Tables["tool_information"].Rows.Count; i++)
                {
                    int index = dataGridView2.Rows.Add();
                    this.dataGridView2.Rows[index].Cells[0].Value = stonesysteminfo.Tables["tool_information"].Rows[i][0].ToString();
                    this.dataGridView2.Rows[index].Cells[1].Value = stonesysteminfo.Tables["tool_information"].Rows[i][1].ToString();
                    this.dataGridView2.Rows[index].Cells[2].Value = stonesysteminfo.Tables["tool_information"].Rows[i][2].ToString();
                    this.dataGridView2.Rows[index].Cells[3].Value = stonesysteminfo.Tables["tool_information"].Rows[i][3].ToString();
                    this.dataGridView2.Rows[index].Cells[4].Value = stonesysteminfo.Tables["tool_information"].Rows[i][4].ToString();
                    this.dataGridView2.Rows[index].Cells[5].Value = stonesysteminfo.Tables["tool_information"].Rows[i][5].ToString();
                    this.dataGridView2.Rows[index].Cells[6].Value = stonesysteminfo.Tables["tool_information"].Rows[i][6].ToString();
                    this.dataGridView2.Rows[index].Cells[7].Value = stonesysteminfo.Tables["tool_information"].Rows[i][7].ToString();
                    this.dataGridView2.Rows[index].Cells[8].Value = stonesysteminfo.Tables["tool_information"].Rows[i][8].ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("出现错误" + ex.Message);
            }

            mysqlconncetion.Close();
        }

        private void DataGridView2_RowHeaderMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            this._del((string)dataGridView2.Rows[e.RowIndex].Cells[0].Value, 0);
            this._del((string)dataGridView2.Rows[e.RowIndex].Cells[1].Value, 1);
            this._del((string)dataGridView2.Rows[e.RowIndex].Cells[2].Value, 2);
            this._del((string)dataGridView2.Rows[e.RowIndex].Cells[3].Value, 3);
            this._del((string)dataGridView2.Rows[e.RowIndex].Cells[4].Value, 4);
            this._del((string)dataGridView2.Rows[e.RowIndex].Cells[5].Value, 5);
            this._del((string)dataGridView2.Rows[e.RowIndex].Cells[6].Value, 6);
        }
    }
}
