﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using System.Drawing.Drawing2D;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

using MySql.Data.MySqlClient;

namespace test3
{
    public partial class Form3 : Form
    {
        //connect to the ali mysql
        string str = "server=rm-2ze9sl6dzz720b6t58o.mysql.rds.aliyuncs.com;port = 3306;user = helloworld;password = wuxi*2001;database = stone_processing_system;";

        //global stone variable
        string stoneNumber = "";

        public Form3()
        {
            InitializeComponent();
            timer1.Start();
            this.StartPosition = FormStartPosition.CenterScreen;
            treeView1.ExpandAll();

            MySqlConnection mySqlConnection = new MySqlConnection(str);
            mySqlConnection.Open();

        }

        private void Timer1_Tick(object sender, EventArgs e)
        {
            toolStripStatusLabel1.Text = "时间:   " + System.DateTime.Now.ToString();
            //this.statusStrip1.Refresh();
        }

        private void TabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            tabControl1.TabPages[tabControl1.SelectedIndex].Focus();
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            //给stonenumber 变量赋值
            stoneNumber = textBox2.Text;

            //连接数据库
            MySqlConnection mySqlConnection = new MySqlConnection(str);
            mySqlConnection.Open();

            //判断所有的空格是否填满
            if(textBox1.Text != "" && textBox2.Text != "" && textBox3.Text != "" && comboBox1.Text != "" && textBox6.Text != "" 
                && textBox4.Text != "" && textBox5.Text != "" && textBox7.Text != "" && textBox8.Text != "")
            {
                //convert the image to the imageStream 
                MemoryStream imageStream = new MemoryStream();
                pictureBox3.Image.Save(imageStream, System.Drawing.Imaging.ImageFormat.Jpeg);

                //get byte array of the picture (request memory for the image stream)
                byte[] imageByte = imageStream.GetBuffer();

                //set command parameters about table stone_elseInfo
                string stoneElseInfo_sql = "insert into stone_elseInfo  values('" + textBox2.Text + "','" +
                    textBox1.Text + "','" + textBox3.Text + "','" + comboBox1.Text + "','" + textBox6.Text + "'," + "?imageByte)";
                MySqlCommand stoneElseInfo = new MySqlCommand(stoneElseInfo_sql, mySqlConnection);
                stoneElseInfo.Parameters.Add(new MySqlParameter("?imageByte", MySqlDbType.MediumBlob)).Value = imageByte;
                stoneElseInfo.ExecuteNonQuery();

                //set command parameters about table stone_manager
                string stoneManager_sql = "insert into stone_manager values('" + stoneNumber + "','" + textBox4.Text + "','" +
                    textBox7.Text + "','" + textBox5.Text + "','" + textBox8.Text + "')";
                MySqlCommand stoneManager = new MySqlCommand(stoneManager_sql, mySqlConnection);
                stoneManager.ExecuteNonQuery();

                //release resources
                stoneElseInfo.Dispose();
                stoneManager.Dispose();
                mySqlConnection.Close();

                MessageBox.Show("主要信息已输入数据库中");
                textBox28.Text = stoneNumber;
            }
            else
            {
                MessageBox.Show("请填写完整的石材信息!", "ERROR");
            }
        }

        private void TextBox1_Leave(object sender, EventArgs e)
        {
            //连接数据库
            MySqlConnection mySqlConnection = new MySqlConnection(str);
            mySqlConnection.Open();
            
            if(textBox1.Text != "")
            {
                string constr3 = "select count(name) from stone_types where name = '" + textBox1.Text + "'";
                MySqlCommand mySqlCommand3 = new MySqlCommand(constr3, mySqlConnection);
                if (mySqlCommand3.ExecuteScalar().ToString() != "0")
                {
                    string constr1 = "select abbr_name from stone_types where name = '" + textBox1.Text + "'";
                    MySqlCommand mySqlCommand1 = new MySqlCommand(constr1, mySqlConnection);

                    string constr2 = "select count(stoneNumber) from stone_elseinfo where stoneName = '" + textBox1.Text + "'";
                    MySqlCommand mySqlCommand2 = new MySqlCommand(constr2, mySqlConnection);
                    //MessageBox.Show(mySqlCommand2.ExecuteScalar().ToString());
                    textBox2.Text = mySqlCommand1.ExecuteScalar().ToString() + "-" + (Convert.ToInt32(mySqlCommand2.ExecuteScalar()) + 1).ToString();
                }
                else
                {
                    textBox2.Text = "";
                    MessageBox.Show("该石材不属于本数据库石材范围！");
                }
            }
            
        }

        //清除该标签页下控件的值
        private void Button1_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            textBox6.Text = "";
            textBox7.Text = "";
            textBox8.Text = "";
            comboBox1.Text = "";
        }

        //导入图片
        private void Button3_Click(object sender, EventArgs e)
        {
            OpenFileDialog openfile = new OpenFileDialog();
            openfile.Title = "请选择要上传的图片";
            openfile.Filter = "上传图片 (*.jpg;*.bmp;*.png)|*.jpeg;*.jpg;*.bmp;*.png|AllFiles(*.*)|*.*";
            if (DialogResult.OK == openfile.ShowDialog())
            {
                try
                {
                    string image_path = openfile.FileName;
                    pictureBox3.ImageLocation = image_path;
                    pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
                    //Bitmap bmp = new Bitmap(openfile.FileName);
                    //pictureBox3.Image = bmp;
                    //pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
                    //MemoryStream ms = new MemoryStream();
                    //bmp.Save(ms, System.Drawing.Imaging.ImageFormat.Gif);
                    //byte[] arr = new byte[ms.Length];
                    //ms.Position = 0;
                    //ms.Read(arr, 0, (int)ms.Length);
                    //ms.Close();

                    //pic = Convert.ToBase64String(arr);
                }
                catch { }
            }
        }

        private void TreeView1_NodeMouseClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            if(e.Node.Text.ToString() == "主要参数")
            {
                panel1.Visible = false;
                panel1.Visible = true;
                tabControl1.SelectTab(tabPage1);
            }
            if(e.Node.Text.ToString() == "基本参数")
            {
                panel2.Visible = false;
                panel1.Visible = true;
                tabControl1.SelectTab(tabPage2);
            }
            if(e.Node.Text.ToString() == "石材库")
            {
                panel1.Visible = false;
                panel2.Visible = true;
            }
        }

        private void Button4_Click(object sender, EventArgs e)
        {
            if ((checkBox1.Checked != true) || (checkBox2.Checked != true) || (checkBox3.Checked != true))
            {
                //if (checkBox1.Checked == true)
                //{
                //    textBox16.Text = ((100.0 - Convert.ToDouble(textBox13.Text)) / 10.0).ToString();
                //}
                if (checkBox2.Checked == true)
                {
                    if (Convert.ToSingle(textBox10.Text) < 600 && Convert.ToSingle(textBox10.Text) > 500)
                        textBox12.Text = "一";
                    if (Convert.ToSingle(textBox10.Text) < 700 && Convert.ToSingle(textBox10.Text) >= 600)
                        textBox12.Text = "二";
                    if (Convert.ToSingle(textBox10.Text) < 800 && Convert.ToSingle(textBox10.Text) >= 700)
                        textBox12.Text = "三";
                    if (Convert.ToSingle(textBox10.Text) < 900 && Convert.ToSingle(textBox10.Text) >= 800)
                        textBox12.Text = "四";
                    if (Convert.ToSingle(textBox10.Text) < 1000 && Convert.ToSingle(textBox10.Text) >= 900)
                        textBox12.Text = "五";
                    if (Convert.ToSingle(textBox10.Text) >= 1000)
                        textBox12.Text = "六";
                }
            }
            else
            {
                MessageBox.Show("请至少勾选一项进行计算");
            }
        }

        private void Button5_Click(object sender, EventArgs e)
        {
            //连接数据库
            MySqlConnection mySqlConnection = new MySqlConnection(str);
            mySqlConnection.Open();

            //create the command string
            string machinability_sql = "insert into machinability values('" + stoneNumber + "','" + textBox9.Text +
                "','" + textBox10.Text + "','" + textBox11.Text + "','" + textBox12.Text + "')";
            MySqlCommand machinability = new MySqlCommand(machinability_sql, mySqlConnection);
            machinability.ExecuteNonQuery();

            machinability.Dispose();
            mySqlConnection.Close();

            //remind the operator this part of info is ok
            MessageBox.Show("该部分信息已经输入数据库中");
        }

        private void Button7_Click(object sender, EventArgs e)
        {
            MySqlConnection mySqlConnection = new MySqlConnection(str);
            mySqlConnection.Open();

            if(textBox13.Text != "" && textBox14.Text != "" && textBox15.Text != "")
            {
                string stoneingredient_sql = "insert into stone_ingredient values('" + stoneNumber + "','" + textBox13.Text + "','"
                    + textBox14.Text + "','" + textBox15.Text + "','" + textBox18.Text + "','" + textBox17.Text + "','" + textBox16.Text
                    + "','" + textBox21.Text + "','" + textBox20.Text + "','" + textBox19.Text + "','" + textBox24.Text + "','" + textBox23.Text
                    + "','" + textBox22.Text + "','" + textBox27.Text + "','" + textBox26.Text + "','" + textBox25.Text + "')";
                MySqlCommand mySqlCommand = new MySqlCommand(stoneingredient_sql, mySqlConnection);
                mySqlCommand.ExecuteNonQuery();

                mySqlCommand.Dispose();

                MessageBox.Show("该部分信息已经输入数据库中");
            }
            else
            {
                MessageBox.Show("请至少填写一个成分");
            }
        }

        private void Button9_Click(object sender, EventArgs e)
        {
            MySqlConnection mySqlConnection = new MySqlConnection(str);
            mySqlConnection.Open();

            if (textBox28.Text != "" && textBox29.Text != "" && textBox30.Text != "" &&
                comboBox2.Text != "" && textBox31.Text != "" && textBox32.Text != "" &&
                textBox33.Text != "" && textBox34.Text != "" && textBox35.Text != "")
            {
                string stonebaseinfo_sql = "insert into stone_baseinfo values('" + stoneNumber + "','" + textBox29.Text
                    + "','" + textBox30.Text + "','" + comboBox2.Text + "','" + textBox31.Text + "','" + textBox32.Text
                    + "','" + textBox33.Text + "','" + textBox34.Text + "','" + textBox35.Text + "')";

                MySqlCommand stonebaseinfo = new MySqlCommand(stonebaseinfo_sql, mySqlConnection);
                stonebaseinfo.ExecuteNonQuery();

                stonebaseinfo.Dispose();

                MessageBox.Show("石材主要信息已经输入数据库中");
            }
            else
            {
                MessageBox.Show("石材的主要信息没有填写完整");
            }
        }

        private void Button8_Click(object sender, EventArgs e)
        {
            textBox28.Text = "";
            textBox29.Text = "";
            textBox30.Text = "";
            comboBox2.Text = "";
            textBox31.Text = "";
            textBox32.Text = "";
            textBox33.Text = "";
            textBox34.Text = "";
            textBox35.Text = "";
        }

        private void Button6_Click(object sender, EventArgs e)
        {

        }
    }
}
