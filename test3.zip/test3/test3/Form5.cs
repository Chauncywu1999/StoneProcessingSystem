﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using MySql.Data.MySqlClient;



namespace test3
{
    public delegate void DelTest(string str, int n);
    public partial class Form5 : Form 
    {
        //define a global variable for datagridview1.rows
        int dataset1;
        //connect to the mysql database
        string str = "server = 127.0.0.1;user id = root;password=wuxi*2001;database=stone_processing_system";

        public static string stonenumberinfo = "";

        //public event setTextValue setFormTextValue;
        private DelTest _del;
        public Form5(DelTest del)
        {
            this._del = del;
            InitializeComponent();
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            MySqlConnection mysqlconncetion = new MySqlConnection(str);
            mysqlconncetion.Open();
            try
            {
                string stone_information = "select stone_baseinfo.stonenumber,stonename,machinablegrade,length,width,height,stonehardness,cuttingforce,abrasionresistance from machinability,stone_baseinfo,stone_elseinfo where stone_baseinfo.stonenumber = machinability.stonenumber AND stone_baseinfo.stonenumber = stone_elseinfo.stonenumber";
                MySqlDataAdapter stoneinfo_adapter = new MySqlDataAdapter(stone_information, mysqlconncetion);
                DataSet stonesysteminfo = new DataSet();
                stoneinfo_adapter.Fill(stonesysteminfo, "stone_information");
                dataset1 = stonesysteminfo.Tables["stone_information"].Rows.Count;
                for (int i = 0; i < stonesysteminfo.Tables["stone_information"].Rows.Count; i++)
                {
                    int index = dataGridView1.Rows.Add();
                    this.dataGridView1.Rows[index].Cells[0].Value = stonesysteminfo.Tables["stone_information"].Rows[i][0].ToString();
                    this.dataGridView1.Rows[index].Cells[1].Value = stonesysteminfo.Tables["stone_information"].Rows[i][1].ToString();
                    this.dataGridView1.Rows[index].Cells[2].Value = stonesysteminfo.Tables["stone_information"].Rows[i][2].ToString();
                    this.dataGridView1.Rows[index].Cells[3].Value = stonesysteminfo.Tables["stone_information"].Rows[i][3].ToString();
                    this.dataGridView1.Rows[index].Cells[4].Value = stonesysteminfo.Tables["stone_information"].Rows[i][4].ToString();
                    this.dataGridView1.Rows[index].Cells[5].Value = stonesysteminfo.Tables["stone_information"].Rows[i][5].ToString();
                    this.dataGridView1.Rows[index].Cells[6].Value = stonesysteminfo.Tables["stone_information"].Rows[i][6].ToString();
                    this.dataGridView1.Rows[index].Cells[7].Value = stonesysteminfo.Tables["stone_information"].Rows[i][7].ToString();
                    this.dataGridView1.Rows[index].Cells[8].Value = stonesysteminfo.Tables["stone_information"].Rows[i][8].ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("出现错误" + ex.Message);
            }

            mysqlconncetion.Close();
        }

        private void DataGridView1_RowHeaderMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            //Form3 form3 = new Form3();
            //form3.TextBox126Value = (string)dataGridView1.Rows[e.RowIndex].Cells[0].Value;
            //MessageBox.Show(form3.TextBox126Value);

            //setFormTextValue((string)dataGridView1.Rows[e.RowIndex].Cells[0].Value);
            //setFormTextValue((string)dataGridView1.Rows[e.RowIndex].Cells[1].Value);
            //MessageBox.Show((string)dataGridView1.Rows[e.RowIndex].Cells[1].Value);

            this._del((string)dataGridView1.Rows[e.RowIndex].Cells[0].Value, 0);
            this._del((string)dataGridView1.Rows[e.RowIndex].Cells[1].Value, 1);
            this._del((string)dataGridView1.Rows[e.RowIndex].Cells[2].Value, 2);
            this._del((string)dataGridView1.Rows[e.RowIndex].Cells[3].Value, 3);
            this._del((string)dataGridView1.Rows[e.RowIndex].Cells[4].Value, 4);
            this._del((string)dataGridView1.Rows[e.RowIndex].Cells[5].Value, 5);
            this._del((string)dataGridView1.Rows[e.RowIndex].Cells[6].Value, 6);
            this._del((string)dataGridView1.Rows[e.RowIndex].Cells[7].Value, 7);
            this._del((string)dataGridView1.Rows[e.RowIndex].Cells[8].Value, 8);
        }
    }

    //public delegate void setTextValue(string textValue);
}
